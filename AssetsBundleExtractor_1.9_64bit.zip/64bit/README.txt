THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
By using this software, you agree to be bound by the terms and conditions of the license you can find in license.txt (CC BY-NC-SA 3.0).

AssetsBundleExtractor uses the open-source libraries LodePNG (see LodePNG_license.txt), libsquish (see libsquish_license.txt), stb_image (https://github.com/nothings/stb), crunch (https://github.com/richgel999/crunch), LZMA SDK (http://7-zip.org/sdk.html), lz4 (https://github.com/Cyan4973/lz4) and astc-encoder (https://github.com/ARM-software/astc-encoder).
Uses FMOD Sound System, copyright � Firelight Technologies Pty, Ltd., 1994-2015.
This product includes components of the PowerVR Tools Software from Imagination Technologies Limited.

Unity is a registered trademark of Unity Technologies. The creator of this tool is in no way affiliated with Unity Technologies.